import React, { useState } from "react";
import certImg from "./assets/cert.png";
import assemblyCert from "./assets/assembly language.pdf";

function App() {
  const [activeTab, setActiveTab] = useState("systems");
  return (
    <div className="main-container">
      <NavBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      <ProfilePicture />
      <Experience />
      <CurrentWork track={activeTab} />
      {activeTab === "appsec" && <TrainingStats />}
      {activeTab === "systems" ? <SystemsEngineer /> : <AppSecEngineer />}
    </div>
  );
}

export default App;

function NavBar({ activeTab, setActiveTab }) {
  return (
    <nav className="nav-container">
      <ul className="nav-list">
        <li
          className={`nav-item ${activeTab === "systems" ? "active" : ""}`}
          onClick={() => setActiveTab("systems")}
        >
          Systems Engineer
        </li>
        <li
          className={`nav-item ${activeTab === "appsec" ? "active" : ""}`}
          onClick={() => setActiveTab("appsec")}
        >
          Application Security Engineer
        </li>
      </ul>
    </nav>
  );
}

function ProfilePicture() {
  return (
    <div className="profile-section">
      {/* 1. Personal Photo */}
      <div className="profile-image-container">
        <img
          className="profile-image"
          src={"PROFILE_picture.png"}
          alt="Profile"
        />
      </div>

      {/* 2. Simple message about me */}
      <div className="profile-about">
        I'm a developer who loves a challenge. Currently studying Computer Science at KNUST, I have dedicated myself to mastering systems engineering and scalable backend architectures while simultaneously training in application security. I am passionate about continuous learning and applying technical skills to build robust, secure digital infrastructure.
      </div>

      {/* 3. Primary Info */}
      <div className="profile-info-card">
        <div className="info-labels">
          <span>First Name</span>
          <span>Middle Names</span>
          <span>Last Name</span>
          <span>Date Of Birth</span>
          <span>G-mail</span>
          <span>Phone</span>
        </div>
        <div className="info-values">
          <span>Erastus</span>
          <span>Uriah Nyarku</span>
          <span>Kwaw</span>
          <span>11-02-2005</span>
          <span>kwawerastus2</span>
          <span>059-8918-102</span>
        </div>
      </div>
    </div>
  );
}

function Skills({ data }) {
  return (
    <section>
      <h3 className="section-title">
        Tools I bend to my will
      </h3>

      <div className="skills-container">
        {Object.entries(data).map(([category, items]) => (
          <div key={category} className="skill-category">
            <h4 className="category-title">
              {category}
            </h4>

            <div className="skill-grid">
              {items.map((skill) => (
                <div key={skill.text} className="skill-card">
                  <div className="skill-icon-wrapper">
                    <img
                      src={skill.icon}
                      alt={skill.text}
                      className="skill-icon"
                    />
                  </div>
                  <span className="skill-name">
                    {skill.text}
                  </span>
                  <div className="skill-progress-bg">
                    <div
                      className="skill-progress-bar"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Education({ certifications }) {

  return (
    <section className="education-section">
      <div className="education-block">
        <h3 className="education-title">
          My Educational Background
        </h3>
        <ul className="education-list">
          <li>
            Bachelor of Computer Science, KNUST{" "}
            <span style={{ fontSize: "0.85em", opacity: 0.7, fontStyle: "italic" }}>
              (Expected 2028)
            </span>
          </li>
          <li>Student of Codecademy</li>
        </ul>
      </div>

      <div className="education-block">
        <h3 className="education-title">
          Certifications
        </h3>
        <ul className="cert-list">
          {certifications.map((item, index) => (
            <li key={index}>
              <a
                href={item.link}
                target="_blank"
                rel="noopener noreferrer"
                className="cert-item"
              >
                <span>{item.text}</span>
                <img
                  className="cert-icon"
                  src="https://img.icons8.com/material-outlined/24/download--v1.png"
                  alt="download icon"
                />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function SystemsEngineer() {
  const skillsData = {
    infrastructure: [
      {
        text: "Linux",
        level: 85,
        icon: "https://img.icons8.com/color/100/linux.png",
      },
      {
        text: "Nginx",
        level: 70,
        icon: "https://img.icons8.com/color/100/nginx.png",
      },
      {
        text: "AWS",
        level: 60,
        icon: "https://img.icons8.com/color/100/amazon-web-services.png",
      },
    ],
    languages: [
      {
        text: "Python",
        level: 75,
        icon: "https://img.icons8.com/color/100/python.png",
      },
      {
        text: "C++",
        level: 65,
        icon: "https://img.icons8.com/color/100/c-plus-plus-logo.png",
      },
      {
        text: "Bash Scripting",
        level: 75,
        icon: "https://img.icons8.com/color/100/bash.png",
      },
      {
        text: "Java",
        level: 60,
        icon: "https://img.icons8.com/color/100/java-coffee-cup-logo.png",
      },
      {
        text: "Assembly",
        level: 50,
        icon: "https://img.icons8.com/color/100/processor.png",
      }
    ],
    tools: [
      {
        text: "Git/GitHub",
        level: 85,
        icon: "https://img.icons8.com/color/100/git.png",
      },
      {
        text: "Docker",
        level: 70,
        icon: "https://img.icons8.com/color/100/docker.png",
      },
    ],
  };

  const sysEngCerts = [
    {
      text: "CodeCademy certification in Java OOP",
      link: "https://drive.google.com/file/d/1oSABGZI__sQYjPuVAEnqu7ybUZvhRDZn/view?usp=drive_link",
    },
    {
      text: "CodeCademy certification in JavaScript",
      link: "https://drive.google.com/file/d/1quWIEtCYgvljEmsZXEtLKaUplthRBb7y/view?usp=drive_link",
    },
    {
      text: "CodeCademy certification in Linear Algebra",
      link: "https://drive.google.com/file/d/1AD9Ni1slNkkSMRcwpleUI4pAO0RmY4bs/view?usp=drive_link",
    },
    {
      text: "CodeCademy certification in Python",
      link: "https://drive.google.com/file/d/1rBWFzLi3Ya_1d0hCVC43yD1U5D-7s9u5/view?usp=drive_link",
    },
    {
      text: "Computer Architecture: Assembly Language",
      link: assemblyCert,
    },
  ];

  return (
    <>
      <Skills data={skillsData} />
      <Education certifications={sysEngCerts} />
    </>
  );
}

function AppSecEngineer() {
  const skillsData = {
    security: [
      {
        text: "OWASP",
        level: 80,
        icon: "https://img.icons8.com/color/100/security-checked.png",
      },
      {
        text: "Pen Testing",
        level: 70,
        icon: "https://img.icons8.com/color/100/anonymous-mask.png",
      },
      {
        text: "Burp Suite",
        level: 65,
        icon: "https://img.icons8.com/color/100/cyber-security.png",
      },
    ],
    scripting: [
      {
        text: "Python",
        level: 80,
        icon: "https://img.icons8.com/color/100/python.png",
      },
      {
        text: "Bash",
        level: 70,
        icon: "https://img.icons8.com/color/100/bash.png",
      },
    ],
    tools: [
      {
        text: "Kali Linux",
        level: 75,
        icon: "https://img.icons8.com/color/100/kali-linux.png",
      },
      {
        text: "Git/GitHub",
        level: 85,
        icon: "https://img.icons8.com/color/100/git.png",
      },
    ],
  };

  const appSecCerts = [
    {
      text: "UITS Cybersecurity Bootcamp",
      link: certImg,
    },
    {
      text: "CodeCademy certification in Python",
      link: "https://drive.google.com/file/d/1rBWFzLi3Ya_1d0hCVC43yD1U5D-7s9u5/view?usp=drive_link",
    },
    {
      text: "Computer Architecture: Assembly Language",
      link: assemblyCert,
    },
  ];

  return (
    <>
      <Skills data={skillsData} />
      <Education certifications={appSecCerts} />
    </>
  );
}

function Experience() {
  const roles = [
    { title: "Cybersecurity Intern", org: "University Information Technology Services (UITS), KNUST" },
    { title: "Frontend Developer Intern", org: "ErnestLinks Consult" },
  ];
  return (
    <section className="extra-section">
      <h3 className="section-title">Experience</h3>
      <div className="card-grid">
        {roles.map((r) => (
          <div key={r.title} className="info-card">
            <h4 className="card-title">{r.title}</h4>
            <p className="card-sub">{r.org}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function CurrentWork({ track }) {
  const projects = [
    {
      name: "Pentest Home Lab",
      track: "appsec",
      status: "In progress",
      desc: "A lab of virtual machines (VMware Workstation 17 Pro) that recreates the systems taught in TryHackMe's Jr Penetration Tester path, so I can practise attacks end-to-end on my own network.",
      tags: ["VMware", "Kali Linux", "Networking"],
    },
    {
      name: "Hack The Box Training",
      track: "appsec",
      status: "Ongoing",
      desc: "Working through HTB machines on a weekly streak, building towards the HTB pentester certification.",
      tags: ["Enumeration", "Linux", "Privilege escalation"],
    },
    {
      name: "Steam-style Achievement System",
      track: "systems",
      status: "In progress",
      desc: "My own recreation of a game achievement engine: a Python server and dashboard, a small JavaScript SDK, and an open-source 2048 browser game as the demo client.",
      tags: ["Python", "JavaScript", "REST API", "Postman"],
    },
    {
      name: "ML-filtered Forex / Gold Trading Bot",
      track: "systems",
      status: "In progress",
      desc: "A quantitative trading bot that uses an XGBoost classifier (tuned with Optuna) to filter trade signals, plus an experimental agentic XAUUSD bot running on an MT5 demo account.",
      tags: ["Python", "XGBoost", "Optuna", "MetaTrader 5"],
    },
    {
      name: "Low-level Systems Study (AnyPS5)",
      track: "systems",
      status: "Learning",
      desc: "Studying how the AnyPS5 relinker works under the hood: assembly, ELF files and linking, calling conventions (ABIs) and GPU shaders.",
      tags: ["Assembly", "ELF", "ABIs"],
    },
  ];
  return (
    <section className="extra-section">
      <h3 className="section-title">What I'm building right now</h3>
      <div className="card-grid">
        {projects.filter((p) => p.track === track).map((p) => (
          <div key={p.name} className="info-card">
            <div className="card-head">
              <h4 className="card-title">{p.name}</h4>
              <span className="status-pill">{p.status}</span>
            </div>
            <p className="card-desc">{p.desc}</p>
            <div className="tag-row">
              {p.tags.map((t) => <span key={t} className="tag">{t}</span>)}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function TrainingStats() {
  const stats = [
    { label: "HTB Level", value: "19" },
    { label: "HTB Rank", value: "Apprentice" },
    { label: "Weekly streak", value: "5 weeks" },
    { label: "Machines in progress", value: "12" },
  ];
  return (
    <section className="extra-section">
      <h3 className="section-title">Hack The Box progress</h3>
      <div className="stat-row">
        {stats.map((s) => (
          <div key={s.label} className="stat-tile">
            <span className="stat-value">{s.value}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>
      <p className="stat-note">Snapshot as of October 2026 · HTB profile: FlashB0x</p>
    </section>
  );
}
